"use client";
import React, { useEffect, useState } from "react";
import { getUserData } from "../../utils/api";

export default function Profile() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("jwt_token");
    if (!token) return;

    getUserData(token).then((data) => {
      setUser(data);
    });
  }, []);
  console.log("user", user);

  if (!user) return <p>Loading...</p>;
  return (
    <div>
      <div className="m-10 min-w-sm">
        <div className="rounded-lg border bg-white px-4 pt-8 pb-10 shadow-lg">
          <div className="relative mx-auto w-36 rounded-full">
            <span className="absolute right-0 m-3 h-3 w-3 rounded-full bg-green-500 ring-2 ring-green-300 ring-offset-2"></span>
            <img
              className="mx-auto h-auto w-full rounded-full"
              src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png"
              alt=""
            />
          </div>
          <h1 className="my-1 text-center text-xl font-bold leading-8 text-gray-900">
            {user.first_name} {user.last_name}
          </h1>
          <h3 className="font-lg text-semibold text-center leading-6 text-gray-600 uppercase">
            {user.role.name}
          </h3>
          {/* <p className="text-center text-sm leading-6 text-gray-500 hover:text-gray-600">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit.
            Architecto, placeat!
          </p> */}
          <ul className="mt-3 divide-y rounded bg-gray-100 py-2 px-3 text-gray-600 shadow-sm hover:text-gray-700 hover:shadow">
            <li className="flex items-center py-3 text-sm">
              <span>Eamil</span>
              <span className="ml-auto">
                <span className="rounded-full bg-green-200 py-1 px-2 text-xs font-medium text-green-700">
                  {user.email}
                </span>
              </span>
            </li>
            <li className="flex items-center py-3 text-sm">
              <span>Username</span>
              <span className="ml-auto">{user.username} </span>
            </li>
          </ul>
        </div>
      </div>

      {/* <section className="bg-white py-8 antialiased md:py-8">
        <div className="py-4 md:py-8">
          <div className="mb-4 grid gap-4 sm:grid-cols-2 sm:gap-8 lg:gap-16">
            <div className="space-y-4">
              <div className="flex space-x-4">
                <div>
                  <span className="mb-2 inline-block rounded bg-primary-100  py-0.5 text-xs font-medium text-primary-800 uppercase">
                    {user?.role?.name}
                  </span>
                  <h2 className="flex items-center text-xl font-bold leading-none text-gray-900 sm:text-2xl">
                    {user.first_name} {user.last_name}
                  </h2>
                </div>
              </div>
              <dl>
                <dt className="font-semibold text-gray-900">Email Address</dt>
                <dd className="text-gray-500">{user?.email}</dd>
              </dl>
              <dl>
                <dt className="font-semibold text-gray-900">Username</dt>
                <dd className="flex items-center gap-1 text-gray-500">
                  {user?.username}
                </dd>
              </dl>
            </div>
          </div>
        </div>
      </section> */}
    </div>
  );
}
