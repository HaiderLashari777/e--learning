import React from "react";

export default function Dashbaord() {
  return <div>Dashbaord</div>;
}
