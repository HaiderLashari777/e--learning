import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const token = request.cookies.get("jwt_token")?.value; // Get token properly

  if (!token) {
    if (request.nextUrl.pathname === "/") {
    } else {
      return NextResponse.redirect(new URL("/", request.url));
    }
  } else {
    console.log("mmd", token);
    console.log("pathName", request.nextUrl.pathname);
    if (request.nextUrl.pathname === "/") {
      return NextResponse.redirect(new URL("/dashboard", request.url));
    }
  }

  return NextResponse.next();
}

// Apply middleware to protected pages
export const config = {
  matcher: ["/", "/profile", "/dashboard"],
};
