import toast from "react-hot-toast";

export const getUserData = async (token: string) => {
  try {
    const res = await fetch("http://localhost:1337/api/users/me?populate=*", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    if (!res.ok) {
      toast.error("Failed to fetch data");
      throw new Error("Failed to fetch user data");
    }

    return await res.json();
  } catch (error) {
    console.error("Error fetching user data:", error);
    toast.error("Failed to fetch data");
    return null;
  }
};
